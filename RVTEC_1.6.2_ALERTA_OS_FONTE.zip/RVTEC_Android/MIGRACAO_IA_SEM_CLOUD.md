# RVTEC — IA sem Cloudflare e sem Cloud Functions

## Alterações aplicadas ao projeto
- A tela de IA chama o Gemini diretamente pelo SDK Firebase AI Logic (Gemini Developer API).
- Modelo configurado: `gemini-4-hydrogen`.
- Mantidos Firebase Authentication, Firestore, perfis e dados locais.
- Removido o endpoint HTTPS de Cloud Functions da tela da IA.
- Removida a pasta de código e configuração de Firebase Cloud Functions.
- Mantidas as telas e os recursos existentes do aplicativo.

## Configuração necessária no Firebase Console
1. Abra o projeto `rvtech-cfd2e` no Firebase Console.
2. Acesse **AI Services > AI Logic** e selecione **Get started**.
3. Escolha **Gemini Developer API** (não Vertex AI/Agent Platform).
4. Conclua a ativação das APIs e recursos solicitados pelo assistente.
5. Confira a configuração de Firebase AI Logic / App Check antes de distribuir o APK.

## Observações importantes
- O SDK usa o gateway gerenciado Firebase AI Logic; não há Worker, Cloudflare ou Cloud Functions próprios.
- A modalidade gratuita depende das cotas e disponibilidade do Gemini Developer API e pode mudar. A ativação não garante uso ilimitado nem custo zero em qualquer cenário.
- O código mantém a restrição de perfil na interface e antes da chamada. Como a chamada é direta do cliente, essa checagem de papel não substitui uma autorização de servidor contra clientes modificados. Para distribuição comercial, configure App Check e regras/controles adequados no Firebase.
- O projeto não foi publicado nem testado contra o projeto Firebase real nesta etapa. A IA só responderá depois que AI Logic estiver habilitado no Console e o APK for recompilado/instalado.
