package com.rvtec.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;

public class LoginActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,40,63));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,40,63));
        webView = new WebView(this);
        WebSettings st=webView.getSettings();
        st.setJavaScriptEnabled(true); st.setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "RVTECNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/login.html");
    }
    private class Bridge {
        @JavascriptInterface public void openApp() {
            runOnUiThread(() -> startActivity(new Intent(LoginActivity.this, MainActivity.class)));
        }
    }
    @Override protected void onDestroy(){ if(webView!=null) webView.destroy(); super.onDestroy(); }
}
