package com.rvtec.manutencao;

import android.app.Activity;
import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import java.io.InputStream;

import com.google.firebase.FirebaseApp;
import com.google.firebase.appcheck.FirebaseAppCheck;
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory;
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory;
import com.google.firebase.ai.FirebaseAI;
import com.google.firebase.ai.GenerativeModel;
import com.google.firebase.ai.java.GenerativeModelFutures;
import com.google.firebase.ai.type.GenerativeBackend;
import com.google.firebase.ai.type.Content;
import com.google.firebase.ai.type.GenerateContentResponse;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.MoreExecutors;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private GenerativeModelFutures gemini;
    private static final int PHOTO_GALLERY = 702;
    private static final int PHOTO_CAMERA = 703;
    private Bitmap selectedPartPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 40, 63));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 40, 63));

        FirebaseApp app = FirebaseApp.initializeApp(this);
        if (app != null) {
            FirebaseAppCheck appCheck = FirebaseAppCheck.getInstance(app);
            if (BuildConfig.DEBUG) {
                appCheck.installAppCheckProviderFactory(DebugAppCheckProviderFactory.getInstance());
            } else {
                appCheck.installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance());
            }
            GenerativeModel model = FirebaseAI.getInstance(app, GenerativeBackend.googleAI())
                    .generativeModel("gemini-4-hydrogen");
            gemini = GenerativeModelFutures.from(model);
        }

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        webView.addJavascriptInterface(new GeminiBridge(), "RVTECNative");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(request.getResources());
                    } else {
                        request.deny();
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 701);
                    }
                });
            }
        });
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 701);
        }
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("https://wa.me/") || url.startsWith("whatsapp://") ||
                    url.startsWith("mailto:") || url.startsWith("tel:")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PHOTO_GALLERY && requestCode != PHOTO_CAMERA) return;
        if (resultCode != RESULT_OK || data == null) {
            notifyPhotoSelected(false, "Seleção de foto cancelada.");
            return;
        }
        try {
            Bitmap bitmap;
            if (requestCode == PHOTO_CAMERA && data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) {
                bitmap = (Bitmap) data.getExtras().get("data");
            } else {
                Uri uri = data.getData();
                if (uri == null) throw new IllegalArgumentException("A imagem não foi recebida.");
                try (InputStream stream = getContentResolver().openInputStream(uri)) {
                    bitmap = BitmapFactory.decodeStream(stream);
                }
            }
            if (bitmap == null) throw new IllegalArgumentException("Não foi possível ler a imagem.");
            selectedPartPhoto = resizeBitmap(bitmap, 1280);
            notifyPhotoSelected(true, "Foto carregada. Toque em Identificar com IA.");
        } catch (Exception e) {
            notifyPhotoSelected(false, "Erro ao abrir a foto: " + e.getMessage());
        }
    }

    private Bitmap resizeBitmap(Bitmap source, int maxSide) {
        int w = source.getWidth(), h = source.getHeight();
        float scale = Math.min(1f, (float) maxSide / Math.max(w, h));
        if (scale >= 1f) return source;
        return Bitmap.createScaledBitmap(source, Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)), true);
    }

    private void notifyPhotoSelected(boolean ok, String message) {
        if (webView == null) return;
        String js = "window.rvtecPhotoSelected(" + ok + "," + JSONObject.quote(message) + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private void sendPartResult(String requestId, String answer, String error) {
        if (webView == null) return;
        String js = "window.rvtecPartPhotoResult(" + JSONObject.quote(requestId) + "," +
                (answer == null ? "null" : JSONObject.quote(answer)) + "," +
                (error == null ? "null" : JSONObject.quote(error)) + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    private class GeminiBridge {
        @JavascriptInterface
        public void choosePhoto(String source) {
            runOnUiThread(() -> {
                try {
                    if ("camera".equals(source)) {
                        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (camera.resolveActivity(getPackageManager()) != null) startActivityForResult(camera, PHOTO_CAMERA);
                        else notifyPhotoSelected(false, "Câmera não disponível neste aparelho.");
                    } else {
                        Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                        gallery.setType("image/*");
                        gallery.addCategory(Intent.CATEGORY_OPENABLE);
                        startActivityForResult(Intent.createChooser(gallery, "Escolher foto da peça"), PHOTO_GALLERY);
                    }
                } catch (Exception e) { notifyPhotoSelected(false, "Não foi possível abrir câmera/galeria: " + e.getMessage()); }
            });
        }

        @JavascriptInterface
        public void identifyPhoto(String requestId, String prompt) {
            Bitmap photo = selectedPartPhoto;
            if (gemini == null) { sendPartResult(requestId, null, "Firebase AI Logic não inicializou."); return; }
            if (photo == null) { sendPartResult(requestId, null, "Selecione uma foto antes da análise."); return; }
            String safePrompt = prompt == null ? "Identifique este componente industrial." : prompt;
            Content content = new Content.Builder().addImage(photo).addText(safePrompt).build();
            ListenableFuture<GenerateContentResponse> future = gemini.generateContent(content);
            Futures.addCallback(future, new FutureCallback<GenerateContentResponse>() {
                @Override public void onSuccess(GenerateContentResponse response) {
                    String answer = response.getText();
                    sendPartResult(requestId, answer == null ? "Não foi possível identificar a peça." : answer, null);
                }
                @Override public void onFailure(Throwable error) {
                    String message = error.getCause() != null ? error.getCause().getMessage() : error.getMessage();
                    sendPartResult(requestId, null, message == null ? "Falha ao analisar a imagem com Gemini." : message);
                }
            }, MoreExecutors.directExecutor());
        }

        @JavascriptInterface
        public void ask(String requestId, String prompt) {
            if (gemini == null) {
                sendResult(requestId, null, "Firebase não inicializou. Confira google-services.json.");
                return;
            }
            String safePrompt = prompt == null ? "" : prompt;
            if (safePrompt.trim().isEmpty()) {
                sendResult(requestId, null, "Digite uma pergunta.");
                return;
            }
            if (safePrompt.length() > 20000) safePrompt = safePrompt.substring(0, 20000);
            Content content = new Content.Builder().addText(safePrompt).build();
            ListenableFuture<GenerateContentResponse> future = gemini.generateContent(content);
            Futures.addCallback(future, new FutureCallback<GenerateContentResponse>() {
                @Override public void onSuccess(GenerateContentResponse response) {
                    String answer = response.getText();
                    sendResult(requestId, answer == null ? "" : answer, null);
                }
                @Override public void onFailure(Throwable error) {
                    String message = error.getCause() != null ? error.getCause().getMessage() : error.getMessage();
                    sendResult(requestId, null, message == null ? "Falha ao consultar Gemini." : message);
                }
            }, MoreExecutors.directExecutor());
        }
    }

    private void sendResult(String requestId, String answer, String error) {
        if (webView == null) return;
        String js = "window.rvtecGeminiNativeResult(" + JSONObject.quote(requestId) + "," +
                (answer == null ? "null" : JSONObject.quote(answer)) + "," +
                (error == null ? "null" : JSONObject.quote(error)) + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("RVTECNative"); webView.destroy(); }
        super.onDestroy();
    }
}
